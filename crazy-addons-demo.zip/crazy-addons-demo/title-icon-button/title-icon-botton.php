
<?php

 
class sft_title_icon_button extends \Elementor\Widget_Base
{

	public function get_name() {
        return 'sft_title_icon_button';
    }

	public function get_title() {

        return'Titled Icon Buttons';
    }

	public function get_icon() {
        return 'fas fa-sign-in-alt';
    }

	public function get_custom_help_url() {}

	public function get_categories() {
        return ['crazyaddons'];
    }

	public function get_keywords() {
		return ['button'];
	}

	public function get_script_depends() {
        wp_register_script( 'icon-script-esm', 'https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js',' ',' ',true);
        wp_register_script('icon-script','https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js','',' ',true);
        wp_enqueue_script( 'icon-script-esm');
        wp_enqueue_script( 'icon-script');

		return [
			'icon-script-esm',
            'icon-script'

		];
		
	}

	public function get_style_depends() {
		wp_register_style( 'control-style', plugin_dir_url('').'crazyaddons/assets/css/creative-buttons.css');

        
        wp_enqueue_style( 'control-style' );
		return [
			'control-style'
		];
	}

	
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'crazyaddons-td' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,

            ]
        );

        
        $this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-arrow-right',
					'library' => 'solid',
				],
			]
		);

        $this->add_control(
			'icon_button_style',
			[
				'label' => esc_html__( 'Icon Button Style', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'cyan-icon-button-sqr',
				'options' => [
					'cyan-icon-button-sqr'=> esc_html__( 'Cyan Solid Icon Button', 'crazyaddons-td' ),
					'blue-icon-button-sqr'=> esc_html__( 'Blue Solid Icon Button', 'crazyaddons-td' ),
					'red-icon-button-sqr'=> esc_html__( 'Red Solid Icon Button', 'crazyaddons-td' ),
					'cyan-icon-button-cap'=> esc_html__( 'Cyan Solid Capsul Icon Button', 'crazyaddons-td' ),
					'blue-icon-button-cap'=> esc_html__( 'Blue Solid Capsul Icon Button', 'crazyaddons-td' ),
					'red-icon-button-cap'=> esc_html__( 'Red Solid Capsul Icon Button', 'crazyaddons-td' ),
					'cyan-icon-button-sqr-line'=> esc_html__( 'Cyan outline Icon Button', 'crazyaddons-td' ),
					'blue-icon-button-sqr-line'=> esc_html__( 'Blue outline Icon Button', 'crazyaddons-td' ),
					'red-icon-button-sqr-line'=> esc_html__( 'Red outline Icon Button', 'crazyaddons-td' ),
					'cyan-icon-button-cap-line'=> esc_html__( 'Cyan outline Capsul Icon Button', 'crazyaddons-td' ),
					'blue-icon-button-cap-line'=> esc_html__( 'Blue outline Capsul Icon Button', 'crazyaddons-td' ),
					'red-icon-button-cap-line'=> esc_html__( 'Red outline Capsul Icon Button', 'crazyaddons-td' ),
					
				],
                
			]
		);

        $this->add_control(
			'button_title',
			[
				'label' => esc_html__( 'Title', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Download',
				'placeholder' => esc_html__( 'Type your title here', 'crazyaddons-td' ),
			]
		);


		$this->add_control(
			'button_link', [
				'label' => esc_html__( 'Link', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder'=>esc_html__('http://yourlink.com','crazyaddons-td'),
				'url' => '',

			]
		);



		

       

        $this->end_controls_section();


         $this->start_controls_section(
        'style_section',
        [
            'label' => esc_html__( 'Style', 'crazyaddons-td' ),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,

        ]
    );

            $this->add_control(
            'margin',
            [
                'label' => esc_html__( 'Margin', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .crazy-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
            ]
        );

            $this->add_responsive_control(
            'padding',
            [
                'label' => esc_html__( 'Padding', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => ['{{WRAPPER}} .crazy-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',],
                    
            ]
        );

            $this->add_control(
            'text_align',
            [
                'label' => esc_html__( 'Alignment', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'crazyaddons-td' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'crazyaddons-td' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'crazyaddons-td' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'block' => [
						'title' => __( 'Justified', 'crazyaddons-td' ),
						'icon' => 'eicon-text-align-justify',
					],
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'crazyaddons-td' ),
                'type'  =>\Elementor\Controls_Manager::SELECT,
				'selector' =>
                    
                    '{{WRAPPER}} .crazy-button',
                

                'show_label'=>true,
			]
		);
        

         $this->add_group_control(
            \Elementor\Group_Control_Css_Filter::get_type(),
            [
                'name' => 'custom_css_filters',
                'selectors' => ['{{WRAPPER}} .crazy-button',
                

            ],
            ]
        );


        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .crazy-button',

            ]
        );

        $this->add_control(
            'button_title_color',
            [
                'label' => esc_html__( 'Title color', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fffff',
                'selectors' => [
                    '{{WRAPPER}} .crazy-button' => 'color: {{VALUE}}',
                ]
                
            ]
        );




        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => esc_html__( 'Backgroundk', 'crazyaddons-td' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                
                'selector' => '{{WRAPPER}} .crazy-button',
        
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'text_shadow',
                'label' => esc_html__( 'Text Shadow', 'crazyaddons-td' ),
                'selector' => '{{WRAPPER}} .crazy-button',
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'label' => esc_html__( 'Box Shadow', 'crazyaddons-td' ),
                'selector' => '{{WRAPPER}} .crazy-button',
            ]
        );

    



        

        $this->end_controls_section();

    }


    

    protected function render() {

        $settings = $this->get_settings_for_display();
        $textalign=$settings['text_align'];
        $buttonstyle=$settings['icon_button_style'];
      ?>  
      <div style="text-align:<?php echo $textalign;?>">
       
        <a href="<?php echo $settings['button_link']['url'];?>" class="<?php echo $buttonstyle;?> crazy-button" target="_blank">

            <span class='space-after'><?php echo $settings['button_title'];?></span>
       
         <span class='<?php if($buttonstyle=="cyan-icon-button-sqr-line"){
             echo "line-color-cyan";
         }elseif ($buttonstyle=="blue-icon-button-sqr-line") {
            echo "line-color-blue";
         }elseif($buttonstyle=="red-icon-button-sqr-line"){
             echo "line-color-red";
         }elseif ($buttonstyle=='cyan-icon-button-sqr'||$buttonstyle=='blue-icon-button-sqr'||$buttonstyle=='red-icon-button-sqr'){
            echo 'button-inner-icon';
         };?>'>
          <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
        </span>
        </a>
    </div>

 <?php
        }
       


		protected function content_template() {
            

			?>

<# var iconHTML = elementor.helpers.renderIcon( view, settings.icon, { 'aria-hidden': true }, 'i' , 'object' ); #>
            <div style="text-align:{{settings.text_align}};">
             <a href="#" class="{{{settings.icon_button_style}}} crazy-button" target="_blank">
             <span class='space-after'>{{{settings.button_title}}}</span>
        <span class="<?php if($buttonstyle['cyan-icon-button-sqr-line']){
            echo 'line-color-cyan';
        }elseif ($buttonstyle['blue-icon-button-sqr-line']) {
            echo 'line-color-blue';
        }elseif ($buttonstyle['red-icon-button-sqr-line']) {
            echo 'line-color-red';
        } ?>">
            {{{ iconHTML.value }}}
        </span>
            </a>
        </div>
		
			<?php
		}

}