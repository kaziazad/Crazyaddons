<?php
/**
 * Plugin Name: Crazyaddons
 * Description: Auto embed any embbedable content from external URLs into Elementor.
 * Plugin URI:  https://elementor.com/
 * Version:     1.0.1
 * Author:      Kazi Mahmud Al Azad
 * Author URI:  https://developers.elementor.com/
 * Text Domain: crazyaddons-td
 *
 * Elementor tested up to: 3.5.0
 * Elementor Pro tested up to: 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// register categories in elementor

function add_elementor_widget_categories( $elements_manager ) {

    $elements_manager->add_category(
        'crazyaddons',
        [
            'title' => esc_html__( 'CrazyAddonsPro', 'crazyaddons-td' ),
            'icon' => 'fa fa-plug',
        ]
    );
    

}
add_action( 'elementor/elements/categories_registered', 'add_elementor_widget_categories' );



/**
 * Register oEmbed Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_crazyaddons_widget( $widgets_manager ) {

	require_once( __DIR__ . '/group-button/group-button.php' );

	$widgets_manager->register( new \sft_group_button() );

    require_once( __DIR__ . '/creative-buttons/creative-buttons.php' );

    $widgets_manager->register( new \sft_creative_button() );

    require_once( __DIR__ . '/icon-button-single/icon-botton-single.php' );

    $widgets_manager->register( new \sft_icon_button_single() );

    require_once( __DIR__ . '/title-icon-button/title-icon-botton.php' );

    $widgets_manager->register( new \sft_title_icon_button() );
    
}
add_action( 'elementor/widgets/register', 'register_crazyaddons_widget' );


