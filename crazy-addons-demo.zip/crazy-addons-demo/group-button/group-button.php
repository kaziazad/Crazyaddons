
<?php

 
class sft_group_button extends \Elementor\Widget_Base
{

	public function get_name() {
        return 'sft_group_button';
    }

	public function get_title() {

        return'Group Buttons';
    }

	public function get_icon() {
        return 'eicon-drag-n-drop';
    }

	public function get_custom_help_url() {}

	public function get_categories() {
        return ['crazyaddons'];
    }

	public function get_keywords() {
		return ['button'];
	}

	public function get_script_depends() {
       
       
		return [
			
		];
		
	}

	public function get_style_depends() {
		wp_register_style( 'control-style', plugin_dir_url('').'crazyaddons/assets/css/creative-buttons.css');
        wp_enqueue_style( 'control-style' );
		return [
			'control-style'
		];
	}

	
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'crazyaddons-td' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,

            ]
        );

        $this->add_control(
			'button_wrapper_style',
			[
				'label' => esc_html__( 'Button Group Style', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'button-wrapper-cap',
				'options' => [
                    'button-wrapper-cap'  => esc_html__( 'Default', 'crazyaddons-td' ),
					'button-wrapper-cap'  => esc_html__( 'Capsul Style', 'crazyaddons-td' ),
					'button-wrapper-sqr'  => esc_html__( 'Square Style', 'crazyaddons-td' ),
					'button-wrapper-dbl-cap'  => esc_html__( 'Double Capsul Style', 'crazyaddons-td' ),
					
				],
                
                
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'button_title', [
				'label' => esc_html__( 'Title', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Button' , 'crazyaddons-td' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'button_link', [
				'label' => esc_html__( 'Link', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder'=>esc_html__('http://yourlink.com','crazyaddons-td'),
				'url' => '',

			]
		);

		$repeater->add_control(
			'list_color',
			[
				'label' => esc_html__( 'Color', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
				],
			]
		);

        $this->add_control(
			'inner_buttons',
			[
				'label' => esc_html__( 'Buttons', 'crazyaddons-td' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'button_title' => esc_html__( 'Button 1', 'crazyaddons-td' ),
						
					],
					[
						'button_title' => esc_html__( 'Button 2', 'crazyaddons-td' ),
						
					],
					[
						'button_title' => esc_html__( 'Button 3', 'crazyaddons-td' ),
						
					],
				],
				'title_field' => '{{{ button_title }}}',
			]
		);

       

        $this->end_controls_section();


         $this->start_controls_section(
        'style_section',
        [
            'label' => esc_html__( 'Style', 'crazyaddons-td' ),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,

        ]
    );

            $this->add_control(
            'margin',
            [
                'label' => esc_html__( 'Margin', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .crazy-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
            ]
        );

            $this->add_responsive_control(
            'padding',
            [
                'label' => esc_html__( 'Padding', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => ['{{WRAPPER}} .crazy-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',],
                    
            ]
        );

            $this->add_control(
            'text_align',
            [
                'label' => esc_html__( 'Alignment', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'crazyaddons-td' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'crazyaddons-td' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'crazyaddons-td' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
						'title' => __( 'Justified', 'crazyaddons-td' ),
						'icon' => 'eicon-text-align-justify',
					],
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'crazyaddons-td' ),
                'type'  =>\Elementor\Controls_Manager::SELECT,
				'selector' =>
                    
                    '{{WRAPPER}} .crazy-button',
                

                'show_label'=>true,
			]
		);
        

         $this->add_group_control(
            \Elementor\Group_Control_Css_Filter::get_type(),
            [
                'name' => 'custom_css_filters',
                'selectors' => ['{{WRAPPER}} .crazy-button',
                

            ],
            ]
        );


        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .crazy-button',

            ]
        );

        $this->add_control(
            'button_title_color',
            [
                'label' => esc_html__( 'Title color', 'crazyaddons-td' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fffff',
                'selectors' => [
                    '{{WRAPPER}} .crazy-button' => 'color: {{VALUE}}',
                ]
                
            ]
        );




        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => esc_html__( 'Backgroundk', 'crazyaddons-td' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                
                'selector' => '{{WRAPPER}} .crazy-button',
        
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'text_shadow',
                'label' => esc_html__( 'Text Shadow', 'crazyaddons-td' ),
                'selector' => '{{WRAPPER}} .crazy-button',
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'label' => esc_html__( 'Box Shadow', 'crazyaddons-td' ),
                'selector' => '{{WRAPPER}} .primary-blue-cap-group-active',
                
            ]
        );

    



        

        $this->end_controls_section();

    }


    

    protected function render() {

        $settings = $this->get_settings_for_display();
        $wrapper_style= $settings['button_wrapper_style'];

		if ( $settings['inner_buttons'] ) {
			echo '<div class="'.$wrapper_style.'">';
			foreach (  $settings['inner_buttons'] as $button ) {

                if ($wrapper_style=='button-wrapper-cap') 
                {
                    $innerclass='primary-blue-cap-group-active';
                }elseif ($wrapper_style=='button-wrapper-sqr') 
                {
                    $innerclass='primary-blue-sqr-group-active';
                }else {
                    $innerclass='golden-cap-group-active';
                }
				echo '<a href="'.$button['button_link']['url'].'" class="'.$innerclass.' crazy-button" target="_blank">'. $button['button_title'].'</a>';
			}
		
			echo '</div>';
		}

 
        }
       


		protected function content_template() {
           

			?>
			<# if ( settings.inner_buttons ) { #>
			<div class="{{settings.button_wrapper_style}}">
				<# _.each( settings.inner_buttons, function( button ) { #>
					<a class="primary-blue-cap-group-active crazy-button">{{{ button.button_title }}}</a>
					
				<# }); #>

                
				</div>
			<# } #>
			<?php
		}

}